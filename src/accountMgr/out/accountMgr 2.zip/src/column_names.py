
__user_id_column__ = 'user_id'
__email_column__ = 'email'
__password_column__ = 'password'

__email_index__ = 'email-index'
